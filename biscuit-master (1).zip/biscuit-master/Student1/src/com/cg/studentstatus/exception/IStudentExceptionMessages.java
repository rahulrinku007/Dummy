package com.cg.studentstatus.exception;

public interface IStudentExceptionMessages {
	String MESSAGE1="Name should be only alphabets";
	String MESSAGE2="phone number should be only numbers and of 10 digits only";
	String MESSAGE3="age should be between 1 to 100";
	String MESSAGE4="email should be valid";
	String MESSAGE5="please enter date of joining correctly";


}
