package com.cg.studentstatus.exception;

public class StudentException extends Exception{

	public StudentException() {
		super();
	}
	public StudentException(String msg) {
		System.out.println(msg);
	}
}
