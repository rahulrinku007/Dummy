package com.cg.threeseven.ui;

import java.util.Scanner;

public class JobSeeker {
String uname;
void getUname()
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the username: ");
	uname=sc.next();
	validate(uname);
}
void validate(String uname)
{
	if(uname.length()>=12)
	{
		if(uname.contains("_job"))
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("false");
		}
				
	}
	else
	{
		System.out.println("Enter minimum 8 characters in your name and append job");
		getUname();
	}

}
public static void main(String[] args) {
	JobSeeker js=new JobSeeker();
	js.getUname();
}
}
