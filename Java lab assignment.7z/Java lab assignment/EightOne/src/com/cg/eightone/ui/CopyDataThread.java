package com.cg.eightone.ui;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread implements Runnable {

	@Override
	public void run() {
		FileInputStream fileInputStream = null;
		StringBuilder builder = new StringBuilder();
		try {
			fileInputStream = new FileInputStream("D:/Users/vbalusan/Desktop/Source.txt");
			int data;
			int count = 0;
			while ((data = fileInputStream.read()) != -1)

			{
				if (count == 10) {
					builder.append((char) data);
					System.out.println("10 characters are copied");
					Thread.sleep(5000);
					count = 0;
				} else {
					builder.append((char) data);
					count++;
				}
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File not found");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("File not found");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("File interrupted");
		}
		System.out.println(builder);
		FileOutputStream fileOutputStream = null;
		 try {
			fileOutputStream = new FileOutputStream(new File("D:/Users/vbalusan/Desktop/target.txt"));
			fileOutputStream.write(builder.toString().getBytes());
			fileOutputStream.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File not created");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error");
		}
		 System.out.println(builder);
		

	}

}
