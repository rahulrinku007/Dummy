package com.cg.fourtwo.ui;

public class CurrentAccount extends Account{
double overDraft;
public void withDraw(double money) {
	if(money<10000) {
		System.out.println("true");
	}
	else {
		System.out.println("false");	
	}
}
}
