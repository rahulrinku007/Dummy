package com.cg.fourtwo.ui;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p=new Person();
		Account ac=new Account();
		SavingsAccount sa=new SavingsAccount();
		CurrentAccount ca=new CurrentAccount();
		sa.setAccNum();
		ca.setAccNum();
		sa.setBal(100000);
		sa.withDraw(1000);
		ca.withDraw(110);
	}

}
