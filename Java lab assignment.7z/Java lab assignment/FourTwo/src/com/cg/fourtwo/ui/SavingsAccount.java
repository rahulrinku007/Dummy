package com.cg.fourtwo.ui;

public class SavingsAccount extends Account{
final double minBal=500;
public void withDraw(double money) {
	if(bal>=minBal) {
		super.withDraw(money);
		System.out.println("you have less done your withdrawl successfully: ");
		}
	else {
		System.out.println("you have less than min balance: ");
	}
}
}
