package com.cg.fourtwo.ui;

import java.util.Random;

public class Account extends Person {
	
long accNum;
double bal;
Person acchol;
public Account() {
	
}
public Account(double bal,Person acchol) {
	super();
	this.bal=bal;
	this.acchol=acchol;
}
void deposit(double money ) {
	bal=money;
	System.out.println("you have deposited: "+money);
}
	public void withDraw(double money) {
		// TODO Auto-generated method stub
		bal+=money;
		System.out.println("you have withdrawn: "+money);
	}
	double getBal() {
		return bal;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum() {
		Random rand=new Random();
		long accNum1=rand.nextLong();
		this.accNum=accNum1;
	}
	public Person getAccHol() {
		return acchol;
	}
	public void setAccHol(Person accHol) {
		this.acchol=accHol;
	}
	public void setBal(double money) {
		this.bal=bal;
	}
}
