package com.cg.tentwoone.dto.test;


import static org.junit.Assert.assertSame;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.tentwoone.dto.Person;

public class TestClass {
	private static Person p = null;

	@BeforeClass
	public static void beforeClass() {
		p = new Person();
	}

	@Test
	public void test1() {
		p.setFirstName("Rahul");

	}
	
	@Test
	public void test2() {
		p.setLastName("Patnala");

	}
	
	@Test
	public void test3() {
		p.setG('M');	
	}
	
	@Test
	public void test4() {
	String s=p.getLastName();
	assertSame("Patnala", s);

	}
	@Test
	public void test5() {
	String s=p.getFirstName();
	assertSame("Rahul", s);

	}
	@Test
	public void test6() {
	char s=p.getG();
	assertSame('M', s);

	}
	

}
