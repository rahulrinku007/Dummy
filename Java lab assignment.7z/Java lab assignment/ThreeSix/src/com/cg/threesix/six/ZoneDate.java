package com.cg.threesix.six;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class ZoneDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String zid;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter places like America/New_York,Europe/London,Asia/Tokyo, US/Pacific,Africa/Cairo,Australia/Sydney ");
		zid=sc.nextLine();
		ZonedDateTime zd= ZonedDateTime.now(ZoneId.of(zid));
		System.out.println("Display the date and time of given Zone "+zd);
		
	}

}
