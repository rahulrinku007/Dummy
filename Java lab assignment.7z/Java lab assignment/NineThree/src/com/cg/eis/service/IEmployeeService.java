package com.cg.eis.service;

public interface IEmployeeService {
	
	public String findInsuranceScheme(float salary,String designation);

}
