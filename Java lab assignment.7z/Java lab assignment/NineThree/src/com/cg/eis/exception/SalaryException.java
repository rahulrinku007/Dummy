package com.cg.eis.exception;

public class SalaryException extends Exception {
	
	private static final long serialVersionUid=1L;

}
