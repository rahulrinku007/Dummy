
package com.cg.ninetwo.ui;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) throws FileNotFoundException{
		// TODO Auto-generated method stub
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(new File("numbers.txt"));
		String contents=sc.next();
		
		System.out.println("original comments is"+ contents);
		
		String str[]=contents.split(",");
		for(String string:str)
		{
			int value=Integer.parseInt(string);
			if(value %2==0)
			{
				System.out.printf("%d \t ",value);
			}
		}

	}

}
