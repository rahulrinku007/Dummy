package com.cg.eleventhree;

public interface ILogin {
	boolean validate(String user,String password);
	}


