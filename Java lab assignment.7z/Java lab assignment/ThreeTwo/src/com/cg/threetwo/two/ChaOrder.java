package com.cg.threetwo.two;

import java.util.Scanner;

public class ChaOrder {
	String str;
	boolean checkString() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the String: ");
		str=sc.next();
		for(int i=0;i<str.length()-1;i++) {
			if((str.charAt(i))>str.charAt(i+1))
			{
				return false;
			}
		}
		return true;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChaOrder ch=new ChaOrder();
		System.out.println(ch.checkString());
	}

}
