package com.cg.eleventwo;

@FunctionalInterface
public interface IAddSpace {
String spaceAdd(String str );
}
