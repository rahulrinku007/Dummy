package com.cg.labassignmentsevensix.ui;


import java.util.Scanner;
 import java.util.Set;

import com.cg.labassignmentsevensix.dto.EmployeeDto;
 import com.cg.labassignmentsevensix.service.EmployeeServiceImpl;
 import com.cg.labassignmentsevensix.service.IEmployeeService;

public class Main {

 public static void main(String[] args) {
   int ch = 0;
   IEmployeeService service = new EmployeeServiceImpl();
   do {
    printDetails();
    System.out.println("Enter Choice");
    Scanner sc = new Scanner(System.in);
    ch = sc.nextInt();
    switch (ch) {
    case 1:
     System.out.println("Enter Employee Id");
     int eid = sc.nextInt();
     System.out.println("Enter Employee Name");
     String ename = sc.next();
     System.out.println("Enter Employee Salary");
     double esal = sc.nextDouble();
     
     EmployeeDto emp = new EmployeeDto();
     emp.setEid(eid);
     emp.setEname(ename);
     emp.setEsal(esal);
     
     
     if(esal > 5000 && esal < 20000) {
      emp.setDesignation("Associate");
      emp.setInsuranceScheme("C");
     }
     else if(esal >= 20000 && esal < 40000) {
      emp.setDesignation("Developer");
      emp.setInsuranceScheme("B");
     }
     else if(esal > 40000) {
      emp.setDesignation("Manager");
      emp.setInsuranceScheme("A");
     }
     else if(esal <5000) {
      emp.setDesignation("Clerk");
      emp.setInsuranceScheme("No Scheme");
     }
     service.addEmployee(emp);
     System.out.println("ID: "+emp.getEid());
     System.out.println("Name: "+emp.getEname());
     System.out.println("Salary: "+emp.getEsal());
     System.out.println("Designation: "+emp.getDesignation());
     System.out.println("Insurance Scheme: "+emp.getInsuranceScheme());
     break;
    
    case 2 :
     Set<EmployeeDto> allData = service.showSortedEmployee();
     for(EmployeeDto employee : allData) {
      System.out.println("ID: "+employee.getEid());
      System.out.println("Name: "+employee.getEname());
      System.out.println("Salary: "+employee.getEsal());
      System.out.println("Designation: "+employee.getDesignation());
      System.out.println("Insurance Scheme: "+employee.getInsuranceScheme());
     }
     break;

   case 3:
     Scanner scr = new Scanner(System.in);
     System.out.println("Enter employee Insurance scheme like A/B/C");
     String scheme1 = scr.next();
     EmployeeDto empSearch = service.searchEmployee(scheme1);
     if(empSearch == null)
      System.out.println("Employee Not Found");
     else {
      System.out.println("ID: "+empSearch.getEid());
      System.out.println("Name: "+empSearch.getEname());
      System.out.println("Salary: "+empSearch.getEsal());
      System.out.println("Designation: "+empSearch.getDesignation());
      System.out.println("Insurance Scheme: "+empSearch.getInsuranceScheme());
     }
     break;
    case 4:
     System.out.println("Enter Employee ID");
     int eid1 = sc.nextInt();
     service.deleteEmployee(eid1);
     break;
    case 5:
     System.out.println("EXIT");
     System.exit(0);
     break;
    }
   }while(ch!= 5);
  }

 private static void printDetails() {
   System.out.println("1.ADD EMPLOYEE");
   System.out.println("2.SHOW SORTED EMPLOYEE");
   System.out.println("3.SEARCH");
   System.out.println("4.DELETE EMPLOYEE");
   System.out.println("5.EXIT");
  }

}