package com.cg.labassignmentsevensix.dto;

 

public class EmployeeDto {

private int eid;

private String ename;

private double esal;

String designation, insuranceScheme;

public EmployeeDto() {

 

// TODO Auto-generated constructor stub

}

public EmployeeDto(int eid, String ename, double esal, String designation, String insuranceScheme) {

 

this.eid = eid;

this.ename = ename;

this.esal = esal;

this.designation = designation;

this.insuranceScheme = insuranceScheme;

}

public String getDesignation() {

return designation;

}

public void setDesignation(String designation) {

this.designation = designation;

}

public String getInsuranceScheme() {

return insuranceScheme;

}

public void setInsuranceScheme(String insuranceScheme) {

this.insuranceScheme = insuranceScheme;

}

public int getEid() {

return eid;

}

public void setEid(int eid) {

this.eid = eid;

}

public String getEname() {

return ename;

}

public void setEname(String ename) {

this.ename = ename;

}

public double getEsal() {

return esal;

}

public void setEsal(double esal) {

this.esal = esal;

}

 

public int compareTo(EmployeeDto arg0) {

if(this.getEid() > arg0.getEid())

return 1;

else if(this.getEid() < arg0.getEid())

return -1;

else 

return 0;

 