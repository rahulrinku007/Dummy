package com.cg.labassignmentsevensix.service;

import java.util.HashMap;
 import java.util.HashSet;
 import java.util.Set;
 import java.util.TreeSet;

import com.cg.labassignmentsevensix.dto.EmployeeDto;

public class EmployeeServiceImpl implements IEmployeeService{
  HashMap<Integer, EmployeeDto> list = new HashMap<Integer,EmployeeDto>();
  Set<EmployeeDto> mySet = new HashSet<>();
  int key =1;
  @Override
  public void addEmployee(EmployeeDto e) {
   System.out.println("Employee Added successfully");
   mySet.add(e);
   list.put(key++, e);
  }

 @Override
  public Set<EmployeeDto> showSortedEmployee() {
   
   
   return mySet;
  }

 @Override
  public void deleteEmployee(int eid) {
   Set<Integer> keys = list.keySet();
   for(Integer integer :keys) {
    if(eid == integer)
     list.remove(eid);
      
   }
   int found = 0;
   for(EmployeeDto e : mySet) {
    if(e.getEid() == eid) {
     mySet.remove(e);
     found =1;
     break;
    }
   
   if(found==1) {
    System.out.println("Employee Not found");
    
   }
   else {
    System.out.println("Employee id with "+eid+ "is successfully removed ");
   }
   }
  }

 @Override
  public EmployeeDto searchEmployee(String scheme) {
   EmployeeDto esearch = null;
   for(EmployeeDto e1 : mySet) {
    if(e1.getInsuranceScheme()== scheme) {
     esearch = e1;
     break;
    }
   }
   return esearch;
  }

}


 

 

 

package com.cg.labassignmentsevensix.service;

import java.util.Set;

import com.cg.labassignmentsevensix.dto.EmployeeDto;

public interface IEmployeeService {
  public void addEmployee(EmployeeDto emp);
  public Set<EmployeeDto> showSortedEmployee();
  public void deleteEmployee(int eid);
  public EmployeeDto searchEmployee(String scheme);
 }


 

 

