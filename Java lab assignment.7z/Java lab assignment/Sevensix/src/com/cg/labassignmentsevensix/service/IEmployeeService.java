package com.cg.labassignmentsevensix.service;

import java.util.Set;

import com.cg.labassignmentsevensix.dto.EmployeeDto;

public interface IEmployeeService {
  public void addEmployee(EmployeeDto emp);
  public Set<EmployeeDto> showSortedEmployee();
  public void deleteEmployee(int eid);
  public EmployeeDto searchEmployee(String scheme);
 }