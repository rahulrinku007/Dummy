package com.cg.twoone.one;

public class Person {
	String firstname = "Rahul";
	 String	lastname = "Patnala";
	 String gender = "M";
	 int age = 20;
	 double weight = 77.45;
	 void getDetails(){
		  System.out.println("Person Details:");
		  System.out.println("---------------");
		  System.out.println(" First Name: "+firstname+" Last Name: "+lastname+ " Gender: " +gender+ " Age: " +age+ " Weight: "+weight);
		  }
}
