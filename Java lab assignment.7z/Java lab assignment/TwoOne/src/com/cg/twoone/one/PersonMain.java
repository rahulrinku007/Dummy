package com.cg.twoone.one;

import com.cg.twoone.one.Person;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person per=new Person();
		per.getDetails();
	}
}

