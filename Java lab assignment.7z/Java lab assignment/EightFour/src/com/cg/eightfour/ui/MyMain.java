package com.cg.eightfour.ui;

public class MyMain extends Thread {
	
	public void run()
	{
		System.out.println("Customer giving products to billing person");
	}

	public static void main(String[] args) throws InterruptedException {
		MyMain main = new MyMain();
		main.start();
		main.join();
		System.out.println("Billing person bills the products. ");
		

	}

}
