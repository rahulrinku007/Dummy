package com.cg.eighttwo.ui;

import java.util.Date;

public class MyMain implements Runnable {
	
	@Override
	public void run() {
		while(true) {
		System.out.println(new Date());
		try {
			Thread.sleep(10000);
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		}
		
	}
	
	public static void main(String[] args) {
		Thread thread = new Thread(new MyMain());
		thread.start();
	}

}
