package com.cg.sixone.ui;

public class Person {
private String firstName;
private String lastName;
private String g;
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) throws MyException {
	if(firstName.isEmpty()) {
		throw new MyException("names cannot be blank");
	}
	
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) throws MyException {
	if(lastName.isEmpty()) {
		throw new MyException("name cannot be blank");
	}
	else {
	
	this.lastName = lastName;
}
}
public String getg() {
	return g;
}
public void setg(String g) {
	this.g = g;
}


}
