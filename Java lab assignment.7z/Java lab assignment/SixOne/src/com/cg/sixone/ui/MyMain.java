package com.cg.sixone.ui;
import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) throws MyException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Person p=new Person();
		System.out.println("enter first name");
		String firstName=sc.nextLine();
		System.out.println("enter last name");
		String lastName=sc.next();
		System.out.println("Enter Your gender");
		String g=sc.next();
		p.setg(g);
		try {
			p.setFirstName(firstName);
			p.setLastName(lastName);
		}
		catch(MyException e) {
			System.out.println(e.getMessage());
			System.out.println("enter first name");
			firstName=sc.next();
			p.setFirstName(firstName);
			System.out.println("enter last name");
			p.setLastName(lastName);
			}
		finally
		{
			System.out.println("personal Details");
			System.out.println("--------------");
			System.out.println("First Name: "+p.getFirstName());
			System.out.println("Last Name: "+p.getLastName());
			System.out.println("gender:"+p.getg());
			
		}
		
	}

}
