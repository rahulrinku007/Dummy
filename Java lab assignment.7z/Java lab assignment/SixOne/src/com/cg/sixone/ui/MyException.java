package com.cg.sixone.ui;

public class MyException extends Exception {
MyException(){
	super();
}
public MyException(String msg) {
	super(msg);
}
}
