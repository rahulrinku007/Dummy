package com.cg.twotwo.two;

public class NegPosMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NegPos n= new NegPos();
		n.num=Integer.parseInt(args[0]);
		n.checkNum();
	}
}	


