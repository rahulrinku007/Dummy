package com.cg.twotwo.two;

public class NegPos {
	int num;
	void checkNum(){
	if(num>0)
	System.out.println("number is positive");
	else
	System.out.println("number is negative");
	}
}
