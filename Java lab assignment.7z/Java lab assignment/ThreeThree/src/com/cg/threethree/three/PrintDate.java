package com.cg.threethree.three;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class PrintDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DateTimeFormatter formate=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scr=new Scanner(System.in);
		LocalDate today=LocalDate.now();
		LocalDate birthDate=LocalDate.of(1997,Month.DECEMBER,5);
		Period diff=birthDate.until(today);
		System.out.println(" dura in no of Years "+diff.getYears());
		System.out.println(" dura in no of Months "+diff.getMonths());
		System.out.println(" dura in no of Days "+diff.getDays());
	}

}
