package com.cg.twofour.four;

import com.cg.twofour.four.Person;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p= new Person("Rahul","Patnala","M",85004);
		System.out.println("person details");
		System.out.println("--------------");
		System.out.println(" Last name: "+p.getlastname()+" First name: "+p.getfirstname()+" Gender:"+p.getgender()+" Phone "+p.getphone());
	}

	}

