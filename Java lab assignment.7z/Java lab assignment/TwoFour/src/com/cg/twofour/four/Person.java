package com.cg.twofour.four;

public class Person {
	String firstname;
	 String lastname;
	 String gender;
	 long phone;
	 public Person()
	 {
	 }
	 public Person(String first,String last,String g,long phon)
	 {
		 this.firstname=first;
		 this.lastname=last;
		 this.gender=g;
		 this.phone=phon;
	 }
	 public long getphone()
	 {
		 return phone;
	 }
	 public void setphone(long phone)
	 {
		 this.phone=phone;
	 }
	 public String getfirstname()
	 {
		 return firstname;
	 }
	 public void setfirstname(String firstname)
	 {
		 this.firstname=firstname;
	 }
	 public String getlastname() 
	 {
		 return lastname;
	 }
	 public void setlastname(String lastname)
	 {
		 this.lastname=lastname;
	 }
	 public String getgender()
	 {
		 return gender;
	 }
	 public void setgender(String gender)
	 {
		 this.gender=gender;
	 }
}
