package com.cg.twofive.five;

public class Person {
	String firstname;
	 String lastname;
	 public Person()
	 {
	 }
	 public Person(String first,String last)
	 {
		 firstname=first;
		 lastname=last;
	 }
	 public String getfirstname()
	 {
		 return firstname;
	 }
	 public void setfirstname(String firstname)
	 {
		 this.firstname=firstname;
	 }
	 public String getlastname() 
	 {
		 return lastname;
	 }
	 public void setlastname(String lastname)
	 {
		 this.lastname=lastname;
	 }
	 enum Gender{M,F}
}
