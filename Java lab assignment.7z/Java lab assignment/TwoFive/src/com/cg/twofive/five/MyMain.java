package com.cg.twofive.five;

import com.cg.twofive.five.Person;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Person p=new Person("Rahul","Patnala");
		    System.out.println("First Name"+p.getfirstname());
		    System.out.println("Last Name"+p.getlastname());
		    System.out.println("gender"+Person.Gender.M);
		    
	}

}
