package com.cg.twothree.three;

public class Person {
	String firstname;
	 String lastname;
	 char gender;
	 public Person()
	 {
	 }
	 public Person(String first,String last,char g)
	 {
		 firstname=first;
		 lastname=last;
		 gender=g;
	 }
	 public String getfirstname()
	 {
		 return firstname;
	 }
	 public void setfirstname(String firstname)
	 {
		 this.firstname=firstname;
	 }
	 public String getlastname() 
	 {
		 return lastname;
	 }
	 public void setlastname(String lastname)
	 {
		 this.lastname=lastname;
	 }
	 public char getgender()
	 {
		 return gender;
	 }
	 public void setgender(char gender)
	 {
		 this.gender=gender;
	 }
}
