package com.cg.fourone.ui;

public class Account extends Person{
	private long acno;
	private double bal;
	Person acchol;
	public long getAcno() {
		return acno;
	}
	public void setAcno(long acno) {
		this.acno = acno;
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	public Person getAcchol() {
		return acchol;
	}
	public void setAcchol(Person acchol) {
		this.acchol = acchol;
	}
	public void deposit(double dep) {
		bal+=dep;
		System.out.println("account deposited: "+dep+" current balance: "+this.bal+" for account holder "+acchol.getName()+" hold account no: "+acno);
	}
	public void withDraw(double draw) {
		if(this.bal-draw>=500) {
			this.bal=draw;
			System.out.println("account withdrawn "+draw+"current balance "+this.bal+"for account no: "+acchol.getName()+"hold account no:"+acno);
			}
		else {
			System.out.println("balance available "+bal+"minimum withdrawal avail "+(bal-500)+"for account no: "+acchol.getName()+"hold account no:"+acno);
		}
		
		}
	@Override
	public String toString() {
		return "Account [acno=" + acno + ", bal=" + bal + ", acchol=" + acchol + "]";
	}
	}

