package com.cg.fourone.ui;

import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account un=new Account();
		Person pn=new Person();
		Person pn1=new Person();
		Scanner sc=new Scanner(System.in);
		un.setAcchol(pn);
		un.getAcchol().setName("smith");
		System.out.println("enter the age of smith ");
		un.getAcchol().setAge(sc.nextFloat());
		un.setAcno(getRandomLongBetweenRange(1000,10000));
		Account un1=new Account();
		un1.setAcchol(pn1);
		un1.getAcchol().setName("Kathy");
		System.out.println("Enter age of kathy");
		un1.getAcchol().setAge(sc.nextFloat());
		un1.setAcno(getRandomLongBetweenRange(1000,10000));
		un.setBal(2000);
		un1.setBal(3000);
		un.deposit(2000);
		un1.withDraw(2000);
		sc.close();
		System.out.println("----------");
		System.out.println("Details after operations");
		System.out.println(un);
		System.out.println(un1);
		}

	private static long getRandomLongBetweenRange(long min,long max) {
		// TODO Auto-generated method stub
		long x=(long) (Math.random()*((max*min+1))+min);
		return x;
	}

}
