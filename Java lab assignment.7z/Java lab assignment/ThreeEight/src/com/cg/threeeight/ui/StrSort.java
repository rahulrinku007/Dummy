package com.cg.threeeight.ui;

import java.util.Arrays;
import java.util.Scanner;

public class StrSort {
	String[] arr=new String[5];
	void stringSort() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the array value: ");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.next();
		}
		System.out.println("Array values: ");
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		Arrays.sort(arr);
		System.out.println("Arrays after sorting: ");
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		if(arr.length%2==0)
		{
			for(int i=0;i<5;i++)
			{
				if(i<(arr.length)/2)
				{
					arr[i]=arr[i].toUpperCase();
				}
				else
				{
					arr[i]=arr[i].toLowerCase();
				}
			}
			System.out.println("Arrays after converting: ");
			for(int i=0;i<arr.length;i++)
			{
				System.out.println(arr[i]);
			}
		}
		else {
			for(int i=0;i<5;i++)
			{
				if(i<(arr.length)/2+1)
				{
					arr[i]=arr[i].toUpperCase();
				}
				else
				{
					arr[i]=arr[i].toLowerCase();
				}
			}
			System.out.println("Arrays after converting: ");
			for(int i=0;i<arr.length;i++)
			{
				System.out.println(arr[i]);
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StrSort ss=new StrSort();
		ss.stringSort();
	}

}
