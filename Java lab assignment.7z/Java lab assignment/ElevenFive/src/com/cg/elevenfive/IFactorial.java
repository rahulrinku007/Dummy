package com.cg.elevenfive;

@FunctionalInterface
public interface IFactorial {
int factorial(int n);
}

