package com.cg.threefour.four;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class PrintDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	DateTimeFormatter formate=DateTimeFormatter.ofPattern("dd/MM/yyyy")	;
	LocalDate birthDate=LocalDate.of(1992, Month.DECEMBER,25);
	LocalDate anotherDate=LocalDate.of(1997, Month.DECEMBER,05);
	Period diff=birthDate.until(anotherDate);
	System.out.println(" Dura in no of Years "+diff.getYears());
	System.out.println(" Dura in no of Months "+diff.getMonths());
	System.out.println(" Dura in no of Days "+diff.getDays());
	}

}
