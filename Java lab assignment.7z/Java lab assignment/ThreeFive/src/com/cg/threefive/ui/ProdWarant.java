package com.cg.threefive.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class ProdWarant {
	String date;
	int months;
	int years;
	void WarantCal() {
		DateTimeFormatter form=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the date of purchase");
		date=sc.next();
		System.out.println("enter Warantee Years");
		years=sc.nextInt();
		System.out.println("enter Months");
		months=sc.nextInt();
		LocalDate myDate=LocalDate.parse(date,form);
		System.out.println("purchased date: "+date);
		LocalDate t=myDate.plusMonths(months);
		LocalDate t1=t.plusYears(years);
		System.out.println("Warantee is: "+t1.toString());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProdWarant pw=new ProdWarant();
		pw.WarantCal();
	}

}
