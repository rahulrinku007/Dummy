package com.cg;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MapSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[]ar=new int[n];
		for(int i=0;i<n;i++) {
			ar[i]=sc.nextInt();
		}
		Map<Integer,Integer>m1=new HashMap<Integer,Integer>();
		m1=getSquares(ar);

	}

	public static Map getSquares(int[] arr) {
		// TODO Auto-generated method stub
		int n=arr.length;
		int[]sqr=new int[n];
		for(int i=0;i<n;i++) {
			sqr[i]=arr[i]*arr[i];
		}
		Map<Integer,Integer>m=new HashMap<Integer,Integer>();
		for(int i=0;i<n;i++) {
			m.put(arr[i], sqr[i]);
		}
		
		return null;
	}

}
