package com.cg.sixtwo.ui;

public class Account extends Person{
long accnum;
double balance;
Person accholder;
public Account() {
	}
public Account(double balance,Person accholder) {
	super();
	this.balance=balance;
	this.accholder=accholder;
}

void deposit(double money) {
	balance+=money;
	System.out.println("You have deposited rupees: "+money);
}

void withdraw(double money) {
	balance+=money;
	System.out.println("you have withdrawn rupees: "+money);
}
public long getAccnum() {
	return accnum;
}
public void setAccnum(long accnum) {
	this.accnum = accnum;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public Person getAccholder() {
	return accholder;
}
public void setAccholder(Person accholder) {
	this.accholder = accholder;
}

	
	
}
