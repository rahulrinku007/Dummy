package com.cg.sixtwo.ui;

public class CurrentAccount extends Account {

	double overdraft = 10000;

	@Override
	void withdraw(double money) {
		// TODO Auto-generated method stub
		if (money < overdraft) {
			System.out.println("true");
		} else {
			System.out.println("false");
		}

	}
}
