package com.cg.sixtwo.ui;

public class SavingsAccount extends Account{
	final double minbal=500;

	@Override
	void withdraw(double money) {
		// TODO Auto-generated method stub
		if(balance>=minbal) {
			super.withdraw(money);
			System.out.println("you have done your withdrawn successfully");
		}
		else {
			System.out.println("you have insufficient balance");
		}
		
	}
	
	

}
