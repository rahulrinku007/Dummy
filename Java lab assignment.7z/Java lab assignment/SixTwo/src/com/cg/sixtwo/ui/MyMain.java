package com.cg.sixtwo.ui;

import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p=new Person();
		System.out.println("Enter name: ");
		Scanner sc=new Scanner(System.in);
		String name=sc.next();
		System.out.println("Enter age: ");
		float age=sc.nextFloat();
		p.setName(name);
		try {
			p.setAge(age);
			Account a=new Account();
			SavingsAccount sa=new SavingsAccount();
			CurrentAccount ca=new CurrentAccount();
			sa.setAccNum();
			ca.setAccNum();
			sa.setBalance(10000.0);
			sa.wthdraw(1000);
			ca.withdraw(100);
		}
		catch(EmployeeException ee) {
			System.out.println("age should be above 15");
			
			}
		finally {
			
		}
		
		
		
	}

}
