package com.cg.threeone.one;

import java.util.Scanner;

public class MyMain {
	String str="Rahul";
	String str1="Patnala";
	void addString()
	{
		String str2=str.concat(str1);
		System.out.println("After adding string:"+str2);
		menu();
	}
   void replaceStringWithHash()
   {
	   StringBuilder sb=new StringBuilder(str);
	   int count=0;
	   int len=str.length();
	   for(int i=0;i<len;i++)
	   {
		   if(i%2==1)
		   {
			   sb.setCharAt(i,'#');
		   }
	   }
		   System.out.println("string after changing is"+sb.toString());
		   menu();
	   }
	   void removeDuplicate()
	   {
		   String str1="";
		   int i;
		   for(i=0;i<str.length();i++) {
			   if(!str1.contains(String.valueOf(str.charAt(i)))) {
				   str1+=String.valueOf(str.charAt(i));
			   }
			   System.out.println("Resultant String: "+str1+"\n");
			   menu();
			   }
	   }
		   void changeToUpper() {
			   String str1="";
			   int i;
			   for(i=0;i<str.length();i++)
			   {
				   if(i%2!=0)
				   {
					   char c=str.charAt(i);
					   str1+=String.valueOf(c).toUpperCase();
				   }
			   }
			   System.out.println("After converting odd places: "+str1);
			   menu();
					   
				   }
		   void menu() {
			   Scanner sc=new Scanner(System.in);
			   System.out.println("operations to perform: ");
			   System.out.println("enter 1  to add the string itself ");
			   System.out.println("enter 2 to replace odd positions: ");
			   System.out.println("enter 3 to remove duplicate characters in the string: ");
			   System.out.println("enter 4 to change odd characters to uper class: ");
			   int num=sc.nextInt();
			   switch(num) {
			   case 1:{
				   addString();
				   break;
			   }
			   case 2:{
				   replaceStringWithHash();
				   break;
			   }
			   case 3:{
				   removeDuplicate();
				   break;
			   }
			   case 4:{
				   changeToUpper();
				   break;
			   }
			   default:{
				   break;
			   }
		   }
			   
	   }
   
	   public static void main(String[] args) {
		   MyMain mn=new MyMain();
		   mn.menu();
	   }
	   }	   