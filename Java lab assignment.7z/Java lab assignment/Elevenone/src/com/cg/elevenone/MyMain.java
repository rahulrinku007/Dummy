package com.cg.elevenone;



public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ICalculation d1=(a,b)->{
			
			System.out.println((int)(Math.pow(a, b)));
			   
		};
		d1.power(2,5);
	}

}
