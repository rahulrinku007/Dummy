package com.cg.elevenone;

public interface ICalculation {

	public void power(int a, int b);
}
