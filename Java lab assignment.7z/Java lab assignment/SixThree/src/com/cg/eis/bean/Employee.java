package com.cg.eis.bean;

import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeService;

public class Employee implements EmployeeService{
	public int id;
	public String name;
	public int salary;
	public String designation;
	public String insuranceScheme;
	public Employee() {
		
	}
	public Employee(int id,String name,int salary,String designation,String insuranceScheme) {
		super();
		this.id=id;
		this.name=name;
		this.salary=salary;
		this.designation=designation;
		this.insuranceScheme=insuranceScheme;
		
		}
	
	

	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public int getSalary() {
		return salary;
	}
	public void setId(int id) {
		// TODO Auto-generated method stub
		this.id=id;
	}

	public void setName(String name) {
		// TODO Auto-generated method stub
		this.name=name;
	}

	public void setSalary(int salary) throws EmployeeException {
		// TODO Auto-generated method stub
		if(salary<3000) {
			throw new EmployeeException("please enter salary>3000");
		}
		else {
			this.salary=salary;
		}
		if(salary<5000) {
			setDesignation("clerk");
			setInsuranceScheme("No scheme");
		}
		else if((salary>5000)&&(salary<20000)) {
			setDesignation("System Associate");
			setInsuranceScheme("Scheme c");
		}
		else if((salary>=20000)&&(salary<40000)) {
			setDesignation("Programmer");
			setInsuranceScheme("Scheme B");
		}
		else if(salary>=40000) {
			setDesignation("Manager");
			setInsuranceScheme("Scheme A");
		}
		else {
			System.out.println("enter correct salary");
		}
		
		
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", designation=" + designation
				+ ", insuranceScheme=" + insuranceScheme + "]";
	}
	@Override
	public void showDetails() {
		// TODO Auto-generated method stub
		
	}

	

}
