package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class MyMain {

	private static String designation;
	private static String insuranceScheme;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e=new Employee();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name: ");
		String name=sc.next();
		System.out.println("Enter id: ");
		int id=sc.nextInt();
		System.out.println("Enter salary: ");
		int salary=sc.nextInt();
		e.setId(id);
		e.setName(name);
		try {
			e.setSalary(salary);
		}
		catch(EmployeeException ee) {
			System.out.println("enter salary > 3000");
		}
		 designation = e.getDesignation();
		insuranceScheme = e.getInsuranceScheme();
		System.out.println(e.toString());
		
	}

}
