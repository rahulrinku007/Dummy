package com.cg.service;

import java.math.BigDecimal;

import com.cg.bean.Customer;
import com.cg.bean.Wallet;
import com.cg.repo.WalletRepo;
import com.cg.repo.WalletRepoImpl;

public class WalletServiceImpl implements WalletService {

	WalletRepo repo = null;

	@Override
	public Customer createAccount(String name, String mobileNo, BigDecimal amount) {
		repo = new WalletRepoImpl();
		Wallet wallet = new Wallet(amount);
		Customer customer = new Customer(name, mobileNo, wallet);
		if (repo.save(customer)) {
			return customer;
		}
		return null;
	}

	@Override
	public Customer showBalance(String mobileNo) {

		return repo.findOne(mobileNo);
	}

	@Override
	public Customer fundTransfer(String sourceMob, String targetMob, BigDecimal amount) {
		Customer customer = repo.findOne(sourceMob);
		Wallet wallet = customer.getWallet();
		wallet.setBalance(wallet.getBalance().subtract(amount));

		Customer customer1 = repo.findOne(targetMob);
		Wallet wallet1 = customer1.getWallet();
		wallet1.setBalance(wallet1.getBalance().add(amount));

		return customer1;
	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		Customer customer = repo.findOne(mobileNo);
		Wallet wallet = customer.getWallet();
		wallet.setBalance(wallet.getBalance().add(amount));
		return customer;
	}

}
