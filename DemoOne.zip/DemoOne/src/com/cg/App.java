package com.cg;

import java.math.BigDecimal;
import java.util.Scanner;

import com.cg.bean.Customer;
import com.cg.service.WalletService;
import com.cg.service.WalletServiceImpl;

public class App {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		WalletService service = new WalletServiceImpl();
		int choice = 0;
		do {
			System.out.println("1.Create Account");
			System.out.println("2.Show");
			System.out.println("3.Fund Transfer");
			System.out.println("4.Deposit");
			System.out.println("5.Exit");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter Name: ");
				String name = scanner.next();
				System.out.println("Enter Mobile Number: ");
				String mobile = scanner.next();
				System.out.println("Enter balance");
				BigDecimal balance = scanner.nextBigDecimal();
				Customer customer = service.createAccount(name, mobile, balance);
				System.out.println(customer);
				break;
			case 2:
				System.out.println("Enter mobile number");
				String mobileNo = scanner.next();
				Customer customer1 = service.showBalance(mobileNo);
				System.out.println(customer1);
				break;
			case 3:
				System.out.println("Enter source mobile number");
				String mobile1 = scanner.next();
				System.out.println("Enter target mobile number");
				String mobile2 = scanner.next();
				System.out.println("Enter amount to transfer");
				BigDecimal amount = scanner.nextBigDecimal();
				Customer customer2 = service.fundTransfer(mobile1, mobile2, amount);
				System.out.println(customer2);
				break;
			case 4:
				System.out.println("Enter  mobile number");
				String mobile3 = scanner.next();
				System.out.println("Enter amount to deposit");
				BigDecimal amount1 = scanner.nextBigDecimal();
				Customer customer3 = service.depositAmount(mobile3, amount1);
				System.out.println(customer3);
				break;
			case 5:
				System.out.println("Thank you");
				System.exit(0);
				break;

			default:
				break;
			}

		} while (choice != 5);

	}

}
